# Apresentação — Parte 1

## Problema
O Grupo Sousa Tratores e Serviços precisa organizar os horários em que seus tratores serão utilizados.

## Solução
Foi criado um sistema web simples para registrar cliente, data, horário, serviço, trator e quantidade de horas.

## Por que é apenas a Parte 1?
A disciplina trabalha a construção gradual do sistema. Nesta primeira versão, o objetivo é demonstrar HTML, CSS, React, componentes e Flexbox de forma simples. No próximo semestre, o mesmo projeto poderá receber banco de dados e novas funcionalidades sem precisar ser refeito do zero.

## Demonstração
1. Abrir o sistema.
2. Preencher o formulário.
3. Clicar em "Agendar".
4. Mostrar o registro aparecendo na tabela.
5. Explicar que os dados desta versão ficam apenas durante a execução da página.
